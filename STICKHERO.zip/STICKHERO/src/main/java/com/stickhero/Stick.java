package com.stickhero;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Stick {
    private double baseX, baseY, length, angle;

    public Stick(double baseX, double baseY) {
        this.baseX = baseX;
        this.baseY = baseY;
        this.length = 0;
        this.angle = 0;
    }

    public void grow(double inc) { length += inc; }
    public void rotate(double d) {
        angle = Math.min(90, angle + d);
    }
    public void setAngle(double a) {
        angle = Math.min(90, a);
    }

    public void render(GraphicsContext gc) {
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(5);
        double ex = baseX + length * Math.sin(Math.toRadians(angle));
        double ey = baseY - length * Math.cos(Math.toRadians(angle));
        gc.strokeLine(baseX, baseY, ex, ey);
    }

    public double getBaseX() { return baseX; }
    public double getBaseY() { return baseY; }
    public double getLength(){ return length; }
    public double getAngle() { return angle; }
    public void reset()      { length = 0; angle = 0; }
}
