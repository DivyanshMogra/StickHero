package com.stickhero;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Stick {
    private double baseX;
    private double baseY;
    private double length;
    private double angle;  // 0 vertical, rotates up to 90 horizontal.

    public Stick(double baseX, double baseY) {
        this.baseX = baseX;
        this.baseY = baseY;
        this.length = 0;
        this.angle = 0;
    }

    public void grow(double increment) {
        this.length += increment;
    }

    public void rotate(double degrees) {
        this.angle += degrees;
        if (this.angle > 90) {
            this.angle = 90;
        }
    }

    public void setAngle(double angle) {
        if (angle > 90) {
            this.angle = 90;
        } else {
            this.angle = angle;
        }
    }

    public void render(GraphicsContext gc) {
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(5);
        double endX = baseX + length * Math.sin(Math.toRadians(angle));
        double endY = baseY - length * Math.cos(Math.toRadians(angle));
        gc.strokeLine(baseX, baseY, endX, endY);
    }

    public double getLength() {
        return length;
    }
    public double getAngle() {
        return angle;
    }

    public void reset() {
        length = 0;
        angle = 0;
    }

    public double getBaseX() {
        return baseX;
    }
    public double getBaseY() {
        return baseY;
    }
}
