package com.stickhero.gamestate;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;

public interface GameState {
    void handleInput(KeyEvent event);
    void update();
    void render(GraphicsContext gc);
}
