package com.stickhero.gamestate;

import com.stickhero.GameManager;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;

public class PlayingState implements GameState {
    private final GameManager gameManager;

    public PlayingState(GameManager gm) {
        this.gameManager = gm;
    }

    @Override
    public void handleInput(KeyEvent event) {
        if (event.getEventType() == KeyEvent.KEY_PRESSED) {
            if (event.getCode() == KeyCode.SPACE) {
                gameManager.setGrowing(true);
            } else if (event.getCode() == KeyCode.S) {
                gameManager.saveGame();
            }
        } else if (event.getEventType() == KeyEvent.KEY_RELEASED) {
            if (event.getCode() == KeyCode.SPACE) {
                gameManager.setGrowing(false);
                gameManager.setStickFalling(true);
            }
        }
    }

    @Override
    public void update() {
        gameManager.update();
    }

    @Override
    public void render(GraphicsContext gc) {
        // draw platforms, hero, stick…
        gameManager.getCurrentPlatform().render(gc);
        gameManager.getNextPlatform().render(gc);
        gameManager.getStickHero().render(gc);
        gameManager.getStick().render(gc);

        // HUD
        gc.setFill(Color.BLACK);
        gc.fillText("Score: "      + gameManager.getScore(),     10, 20);
        gc.fillText("High Score: " + gameManager.getHighScore(), 10, 40);
        gc.fillText("Cherries: "   + gameManager.getCherries(),  10, 60);
    }
}
