package com.stickhero.gamestate;

import com.stickhero.GameManager;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;

public class PlayingState implements GameState {
    private final GameManager gameManager;

    public PlayingState(GameManager gm) {
        this.gameManager = gm;
    }

    @Override
    public void handleInput(KeyEvent e) {
        if (e.getEventType() == KeyEvent.KEY_PRESSED) {
            if (e.getCode() == KeyCode.SPACE) {
                gameManager.setGrowing(true);
            } else if (e.getCode() == KeyCode.S) {
                gameManager.saveGame();
            }
        } else if (e.getEventType() == KeyEvent.KEY_RELEASED) {
            if (e.getCode() == KeyCode.SPACE) {
                gameManager.setGrowing(false);
                gameManager.setStickFalling(true);
            }
        }
    }

    @Override
    public void update() {
        gameManager.update();
    }

    @Override
    public void render(GraphicsContext gc) {
        gameManager.getCurrentPlatform().render(gc);
        gameManager.getNextPlatform().render(gc);
        gameManager.getStickHero().render(gc);
        gameManager.getStick().render(gc);

        gc.setFill(Color.BLACK);
        gc.fillText("Score: "      + gameManager.getScore(),     10, 20);
        gc.fillText("High Score: " + gameManager.getHighScore(), 10, 40);
        gc.fillText("Cherries: "   + gameManager.getCherries(),  10, 60);
    }
}
