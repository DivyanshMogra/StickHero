package com.stickhero.gamestate;

import com.stickhero.GameManager;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;

public class GameOverState implements GameState {
    private GameManager gameManager;

    public GameOverState(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    @Override
    public void handleInput(KeyEvent event) {
        // For example, press ENTER to exit.
        if(event.getCode() == javafx.scene.input.KeyCode.ENTER) {
            System.exit(0);
        }
    }

    @Override
    public void update() {
        // No update logic in game over.
    }

    @Override
    public void render(GraphicsContext gc) {
        gc.setFill(Color.BLACK);
        gc.fillText("Game Over!", 350, 300);
        gc.fillText("Press ENTER to exit.", 330, 320);
    }
}
