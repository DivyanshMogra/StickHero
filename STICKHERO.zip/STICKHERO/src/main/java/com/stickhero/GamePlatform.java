package com.stickhero;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class GamePlatform {
    private double x, y, width, height;

    public GamePlatform(double x, double y, double width) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = 20;
    }

    public void render(GraphicsContext gc) {
        gc.setFill(Color.SADDLEBROWN);
        gc.fillRect(x, y, width, height);
    }

    public double getX()      { return x; }
    public double getY()      { return y; }
    public double getWidth()  { return width; }
    public double getHeight() { return height; }
    public void setX(double x){ this.x = x; }
}
