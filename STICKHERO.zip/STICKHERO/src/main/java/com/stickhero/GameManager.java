package com.stickhero;

import com.stickhero.gamestate.GameState;
import com.stickhero.gamestate.PlayingState;
import javafx.application.Platform;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.*;
import javafx.scene.shape.ArcType;

import java.util.prefs.Preferences;

public class GameManager {
    private final GraphicsContext gc;
    private volatile boolean running = true;
    private GameState currentState;

    private int score, cherries, highScore;
    private final Preferences prefs = Preferences.userNodeForPackage(Main.class);

    private StickHero stickHero;
    private GamePlatform currentPlatform, nextPlatform;
    private Stick stick;

    private final GameSettings settings = GameSettings.getInstance();
    private boolean isGrowing, stickFalling, isTransitioning;

    public GameManager(GraphicsContext gc) {
        this.gc = gc;
        this.highScore = prefs.getInt("highScore", 0);

        currentPlatform = new GamePlatform(50, 400, 100);
        nextPlatform    = new GamePlatform(250, 400, 80);

        stick     = new Stick(currentPlatform.getX() + currentPlatform.getWidth(),
                currentPlatform.getY());
        stickHero = new StickHero(currentPlatform.getX() + currentPlatform.getWidth()/2, 380);

        currentState = new PlayingState(this);
    }

    /** The main game loop. */
    public void gameLoop() {
        final long FPS = 60, FRAME = 1000 / FPS;
        while (running) {
            long start = System.currentTimeMillis();

            currentState.update();

            // 1) SKY BACKGROUND GRADIENT
            LinearGradient skyGrad = new LinearGradient(
                    0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.web("#4A90E2")),
                    new Stop(1, Color.web("#357ABD"))
            );
            gc.setFill(skyGrad);
            gc.fillRect(0, 0, Main.WIDTH, Main.HEIGHT);

            // 2) MOUNTAIN RANGES
            drawMountains();

            // 3) GROUND
            double groundY = currentPlatform.getY() + currentPlatform.getHeight();
            gc.setFill(Color.web("#2E2E2E"));
            gc.fillRect(0, groundY, Main.WIDTH, Main.HEIGHT - groundY);

            // 4) ENTITIES
            currentState.render(gc);

            // 5) FRAME CAP
            long delta = System.currentTimeMillis() - start;
            if (delta < FRAME) {
                try { Thread.sleep(FRAME - delta); }
                catch (InterruptedException ignored) {}
            }
        }
    }

    private void drawMountains() {
        // Far mountains (darker blue)
        gc.setFill(Color.web("#336699"));
        gc.beginPath();
        gc.moveTo(-100, 400);
        gc.lineTo(150, 250);
        gc.lineTo(300, 400);
        gc.lineTo(500, 300);
        gc.lineTo(650, 400);
        gc.lineTo(Main.WIDTH + 100, 250);
        gc.lineTo(Main.WIDTH + 100, 600);
        gc.closePath();
        gc.fill();

        // Near mountains (lighter blue)
        gc.setFill(Color.web("#6699CC"));
        gc.beginPath();
        gc.moveTo(-100, 400);
        gc.lineTo(200, 300);
        gc.lineTo(350, 400);
        gc.lineTo(550, 320);
        gc.lineTo(700, 400);
        gc.lineTo(Main.WIDTH + 100, 300);
        gc.lineTo(Main.WIDTH + 100, 600);
        gc.closePath();
        gc.fill();
    }

    public void handleInput(javafx.scene.input.KeyEvent e) {
        currentState.handleInput(e);
    }

    public void setState(GameState s) {
        currentState = s;
    }

    // --- Scoring & Persistence ---
    public int getScore() { return score; }
    public void addScore(int v) {
        score += v;
        if (score > highScore) {
            highScore = score;
            prefs.putInt("highScore", highScore);
        }
    }
    public int getHighScore() { return highScore; }
    public int getCherries()  { return cherries; }
    public void addCherries(int v)    { cherries += v; }
    public void deductCherries(int v) { cherries -= v; }

    /** Called on fall: stops loop & shows Game-Over screen. */
    public void gameOver() {
        running = false;
        int finalScore = score;
        Platform.runLater(() -> Main.showGameOverScreen(finalScore));
    }

    public void saveGame() {
        System.out.printf("Saved: score=%d highScore=%d cherries=%d%n",
                score, highScore, cherries);
    }

    // --- Entities ---
    public StickHero    getStickHero()      { return stickHero; }
    public GamePlatform getCurrentPlatform(){ return currentPlatform; }
    public GamePlatform getNextPlatform()   { return nextPlatform; }
    public Stick        getStick()          { return stick; }
    public GameSettings getSettings()       { return settings; }

    // --- Flags ---
    public boolean isGrowing()               { return isGrowing; }
    public void    setGrowing(boolean g)     { isGrowing = g; }
    public boolean isStickFalling()          { return stickFalling; }
    public void    setStickFalling(boolean f){ stickFalling = f; }
    public boolean isTransitioning()         { return isTransitioning; }
    public void    setTransitioning(boolean t){ isTransitioning = t; }

    // --- Platform Generation & Animation ---
    private void generateNewNextPlatform() {
        double gap = 80 + Math.random()*70;
        double x   = currentPlatform.getX() + currentPlatform.getWidth() + gap;
        double w   = 50 + Math.random()*100;
        nextPlatform = new GamePlatform(x, currentPlatform.getY(), w);
    }

    private void animateTransition() {
        double target = 50, curr = currentPlatform.getX();
        if (curr > target) {
            double shift = Math.min(10, curr - target);
            currentPlatform.setX(curr - shift);
            nextPlatform.setX(nextPlatform.getX() - shift);
            stickHero.setX(stickHero.getX() - shift);
            stick = new Stick(
                    currentPlatform.getX()+currentPlatform.getWidth(),
                    currentPlatform.getY()
            );
        } else {
            currentPlatform.setX(target);
            isTransitioning = false;
        }
    }

    /** Public update() for PlayingState */
    public void update() {
        if (isTransitioning) {
            animateTransition();
            return;
        }
        if (isGrowing) {
            stick.grow(settings.getStickGrowthRate());
        }
        if (isStickFalling()) {
            if (stick.getAngle() < 90) {
                stick.rotate(5);
            } else {
                stick.setAngle(90);
                setStickFalling(false);
                double endX = stick.getBaseX()
                        + stick.getLength()*Math.sin(Math.toRadians(stick.getAngle()));
                if (endX >= nextPlatform.getX()
                        && endX <= nextPlatform.getX()+nextPlatform.getWidth()) {
                    stickHero.setX(nextPlatform.getX()+nextPlatform.getWidth()/2);
                    addScore(1);
                    currentPlatform = nextPlatform;
                    generateNewNextPlatform();
                    stick = new Stick(
                            currentPlatform.getX()+currentPlatform.getWidth(),
                            currentPlatform.getY()
                    );
                    setTransitioning(true);
                } else {
                    gameOver();
                }
                stick.reset();
            }
        }
    }
}
