package com.stickhero;

import com.stickhero.gamestate.GameState;
import com.stickhero.gamestate.PlayingState;
import javafx.application.Platform;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.*;

import java.util.prefs.Preferences;

public class GameManager {
    private final GraphicsContext gc;
    private volatile boolean running = true;
    private GameState currentState;

    private int score, cherries, highScore;
    private final Preferences prefs = Preferences.userNodeForPackage(Main.class);

    private StickHero stickHero;
    private GamePlatform currentPlatform, nextPlatform;
    private Stick stick;

    private final GameSettings settings = GameSettings.getInstance();
    private boolean isGrowing, stickFalling, isTransitioning;

    public GameManager(GraphicsContext gc) {
        this.gc = gc;
        this.highScore = prefs.getInt("highScore", 0);

        currentPlatform = new GamePlatform(50, 400, 100);
        nextPlatform    = new GamePlatform(250, 400, 80);

        stick     = new Stick(currentPlatform.getX() + currentPlatform.getWidth(),
                currentPlatform.getY());
        stickHero = new StickHero(currentPlatform.getX() + currentPlatform.getWidth()/2, 380);

        currentState = new PlayingState(this);
    }

    public void gameLoop() {
        final long FPS = 60, FRAME = 1000/FPS;
        while (running) {
            long start = System.currentTimeMillis();

            currentState.update();

            // DRAW GRADIENT SKY
            LinearGradient sky = new LinearGradient(
                    0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
                    new Stop(0, Color.LIGHTBLUE),
                    new Stop(1, Color.SKYBLUE)
            );
            gc.setFill(sky);
            gc.fillRect(0, 0, Main.WIDTH, Main.HEIGHT);

            // DRAW GROUND
            double groundY = currentPlatform.getY() + currentPlatform.getHeight();
            gc.setFill(Color.web("#3c763d"));
            gc.fillRect(0, groundY, Main.WIDTH, Main.HEIGHT - groundY);

            currentState.render(gc);

            long delta = System.currentTimeMillis() - start;
            if (delta < FRAME) {
                try { Thread.sleep(FRAME - delta); }
                catch (InterruptedException ignored) {}
            }
        }
    }

    public void handleInput(javafx.scene.input.KeyEvent e) {
        currentState.handleInput(e);
    }

    public void setState(GameState s) {
        currentState = s;
    }

    // SCORES
    public int getScore() { return score; }
    public void addScore(int v) {
        score += v;
        if (score > highScore) {
            highScore = score;
            prefs.putInt("highScore", highScore);
        }
    }
    public int getHighScore() { return highScore; }
    public int getCherries()  { return cherries; }
    public void addCherries(int v)    { cherries += v; }
    public void deductCherries(int v) { cherries -= v; }

    public void gameOver() {
        running = false;
        int finalScore = score;
        Platform.runLater(() -> Main.showGameOverScreen(finalScore));
    }

    public void saveGame() {
        System.out.printf("Saved: score=%d highScore=%d cherries=%d%n",
                score, highScore, cherries);
    }

    // ENTITIES
    public StickHero    getStickHero()      { return stickHero; }
    public GamePlatform getCurrentPlatform(){ return currentPlatform; }
    public GamePlatform getNextPlatform()   { return nextPlatform; }
    public Stick        getStick()          { return stick; }
    public GameSettings getSettings()       { return settings; }

    // FLAGS
    public boolean isGrowing()               { return isGrowing; }
    public void    setGrowing(boolean g)     { isGrowing = g; }
    public boolean isStickFalling()          { return stickFalling; }
    public void    setStickFalling(boolean f){ stickFalling = f; }
    public boolean isTransitioning()         { return isTransitioning; }
    public void    setTransitioning(boolean t){ isTransitioning = t; }

    // PLATFORM + ANIMATION
    private void generateNewNextPlatform() {
        double gap = 80 + Math.random()*70;
        double x   = currentPlatform.getX() + currentPlatform.getWidth() + gap;
        double w   = 50 + Math.random()*100;
        nextPlatform = new GamePlatform(x, currentPlatform.getY(), w);
    }

    private void animateTransition() {
        double target = 50;
        double curr = currentPlatform.getX();
        if (curr > target) {
            double shift = Math.min(10, curr - target);
            currentPlatform.setX(curr - shift);
            nextPlatform.setX(nextPlatform.getX() - shift);
            stickHero.setX(stickHero.getX() - shift);
            stick = new Stick(
                    currentPlatform.getX() + currentPlatform.getWidth(),
                    currentPlatform.getY()
            );
        } else {
            currentPlatform.setX(target);
            isTransitioning = false;
        }
    }

    /** PUBLIC update() for PlayingState to call */
    public void update() {
        if (isTransitioning) {
            animateTransition();
            return;
        }
        if (isGrowing) {
            stick.grow(settings.getStickGrowthRate());
        }
        if (isStickFalling()) {
            if (stick.getAngle() < 90) {
                stick.rotate(5);
            } else {
                stick.setAngle(90);
                setStickFalling(false);
                double endX = stick.getBaseX() +
                        stick.getLength()*Math.sin(Math.toRadians(stick.getAngle()));
                if (endX >= nextPlatform.getX() &&
                        endX <= nextPlatform.getX()+nextPlatform.getWidth()) {

                    stickHero.setX(nextPlatform.getX()+nextPlatform.getWidth()/2);
                    addScore(1);
                    currentPlatform = nextPlatform;
                    generateNewNextPlatform();
                    stick = new Stick(
                            currentPlatform.getX()+currentPlatform.getWidth(),
                            currentPlatform.getY()
                    );
                    setTransitioning(true);
                } else {
                    gameOver();
                }
                stick.reset();
            }
        }
    }
}
