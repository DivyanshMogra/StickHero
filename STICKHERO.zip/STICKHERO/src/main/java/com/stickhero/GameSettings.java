package com.stickhero;

public class GameSettings {
    private static GameSettings instance = null;
    private double stickGrowthRate;
    private int reviveCost;

    private GameSettings() {
        stickGrowthRate = 2.0;
        reviveCost = 5;
    }

    public static GameSettings getInstance() {
        if (instance == null) {
            instance = new GameSettings();
        }
        return instance;
    }

    public double getStickGrowthRate() { return stickGrowthRate; }
    public int    getReviveCost()       { return reviveCost; }
}
