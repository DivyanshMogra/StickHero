package com.stickhero;

public class GameSettings {
    private static GameSettings instance = null;

    private double stickGrowthRate;
    private int reviveCost; // Not used yet, but shown for demonstration

    private GameSettings() {
        stickGrowthRate = 2.0; // pixels per update
        reviveCost = 5;
    }

    public static GameSettings getInstance() {
        if (instance == null) {
            instance = new GameSettings();
        }
        return instance;
    }

    public double getStickGrowthRate() {
        return stickGrowthRate;
    }

    public int getReviveCost() {
        return reviveCost;
    }
}
