package com.stickhero;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    private static Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        primaryStage.setTitle("Stick Hero");
        showIntroScreen();
    }

    /** Intro screen with a styled PLAY button */
    public static void showIntroScreen() {
        VBox layout = new VBox(20);
        layout.getStyleClass().add("intro-screen");

        Button play = new Button("PLAY");
        play.getStyleClass().add("styled-button");
        play.setOnAction(e -> showGameScreen());

        layout.getChildren().add(play);

        Scene scene = new Scene(layout, WIDTH, HEIGHT);
        scene.getStylesheets().add(Main.class.getResource("/style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /** Main game screen with canvas & game loop */
    public static void showGameScreen() {
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        GameManager gm = new GameManager(gc);

        StackPane root = new StackPane(canvas);
        Scene scene = new Scene(root, WIDTH, HEIGHT);
        scene.getStylesheets().add(Main.class.getResource("/style.css").toExternalForm());

        scene.setOnKeyPressed(e -> gm.handleInput(e));
        scene.setOnKeyReleased(e -> gm.handleInput(e));

        primaryStage.setScene(scene);
        primaryStage.show();

        new Thread(gm::gameLoop).start();
    }

    /** Game-Over screen showing only the final score plus Restart/Exit */
    public static void showGameOverScreen(int finalScore) {
        VBox layout = new VBox(20);
        layout.getStyleClass().add("game-over-screen");

        Label lbl = new Label("Your Score: " + finalScore);
        lbl.setStyle("-fx-font-size: 24px; -fx-text-fill: white;");

        Button restart = new Button("Restart");
        restart.getStyleClass().add("styled-button");
        restart.setOnAction(e -> showGameScreen());

        Button exit = new Button("Exit");
        exit.getStyleClass().add("styled-button");
        exit.setOnAction(e -> {
            Platform.exit();
            System.exit(0);
        });

        layout.getChildren().addAll(lbl, restart, exit);

        Scene scene = new Scene(layout, WIDTH, HEIGHT);
        scene.getStylesheets().add(Main.class.getResource("/style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
