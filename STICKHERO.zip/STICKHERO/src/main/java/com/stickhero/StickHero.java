package com.stickhero;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class StickHero {
    private double x;
    private double y;
    private double width;
    private double height;

    public StickHero(double x, double y) {
        this.x = x;
        this.y = y;
        this.width = 20;
        this.height = 20;
    }

    public void render(GraphicsContext gc) {
        gc.setFill(Color.RED);
        gc.fillRect(x, y - height, width, height);
    }

    // Getters/Setters
    public double getX() { return x; }
    public double getY() { return y; }
    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
}
